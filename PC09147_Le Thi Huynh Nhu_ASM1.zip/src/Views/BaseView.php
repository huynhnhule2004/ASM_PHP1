<?php

namespace App\Views;

abstract class BaseView{


    /**
     *Phương thức này dùng để in ra giao diện
     */
    abstract function render();



}